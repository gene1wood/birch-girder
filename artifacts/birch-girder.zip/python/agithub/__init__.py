# Copyright 2012-2016 Jonathan Paugh and contributors
# See COPYING for license details
from agithub.base import VERSION, STR_VERSION

__all__ = ["VERSION", "STR_VERSION"]
