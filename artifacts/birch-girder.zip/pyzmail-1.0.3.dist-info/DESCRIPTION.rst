pyzmail is a high level mail library for Python 2.x & 3.x. It provides functions and classes that help to parse, compose and send emails. pyzmail exists because their is no reasons that handling mails with Python would be more difficult than with Outlook or Thunderbird. pyzmail hide the difficulties of managing the MIME structure and of the encoding/decoding for internationalized emails. pyzmail is well documented, has a lot of code samples and include 2 scripts: pyzsendmail and pyzinfomail


